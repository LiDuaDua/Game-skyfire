﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using UnityEngine;

namespace Tiled2Unity
{
    public class TileObject : MonoBehaviour
    {
        public float TileWidth = 0.0f;
        public float TileHeight = 0.0f;
    }
}
